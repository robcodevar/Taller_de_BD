/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;

/**
 *
 * @author Kevin
 */
public class Libro {
      private int generos;
      public Libro(int generos){
           this.generos=generos;
           
      }
        public int setgenero(int generos){
            return this.generos= generos;
        }
        
        public int getgenero(){
            return generos;
        }
        
        public void main(){
          System.out.println("hay " + this.generos + " generos disponibles");
        }
}
    

