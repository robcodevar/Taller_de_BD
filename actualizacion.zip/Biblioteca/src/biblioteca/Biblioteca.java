/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package biblioteca;

import java.util.Scanner;

/**
 *
 * @author Kevin
 */
public class Biblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner cs = new Scanner(System.in);
           String opcion1[] = {"1.- ACCIÓN  --- It, The walking dead, El alma"};
           String opcion2[] = {"2.- FICCIÓN --- El señor de los anillos,La piedra filosofal"};
           String opcion3[] = {"3.- FICCIÓN --- Star Wars,Viaje al futuro"};
           for(int i = 0; i < opcion1.length; i++){
               System.out.println(opcion1[i]);
            }
           for(int i = 0; i < opcion2.length; i++){
               System.out.println(opcion2[i]);
            }
           for(int i = 0; i < opcion3.length; i++){
               System.out.println(opcion3[i]);
            }
         Libro Genero = new Libro(3);
        Genero.main();       
    }
    
}
